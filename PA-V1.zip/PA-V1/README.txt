INSTALL INSTRUCTIONS.

Extract both files, and add Project Affliction_Data into PA-V1.
